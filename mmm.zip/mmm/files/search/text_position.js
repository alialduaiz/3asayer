﻿var positionForPages = [];
